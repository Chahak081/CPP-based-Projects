#include "UserFunc.h"

void UserFunc::FindRoute()
{
	string source, dest;

	// User Input for starting station
	cout << endl << "Enter the starting station here : ";
	fflush(stdin);
	getline(cin, source);

	// User Input for ending station
	cout << endl << "Enter the ending station here : ";
	fflush(stdin);
	getline(cin, dest);
	
	PutPath(source, dest);
	CalcFare();

}

void UserFunc::SaveRoute()
{
	string label, source, dest, uname;

	// User Input for starting station
	cout << endl << "Enter the starting station here : ";
	fflush(stdin);
	getline(cin, source);

	// User Input for ending station
	cout << endl << "Enter the ending station here : ";
	fflush(stdin);
	getline(cin, dest);

	PutPath(source, dest);
	CalcFare();
	
	filePtr = &sRoute;

	fstream myFile = filePtr->WriteFile();

	cout << endl << "What label would you like to give this route?: ";
	fflush(stdin);
	getline(cin, label);

	cout << endl << "Please confirm your username: ";
	fflush(stdin);
	getline(cin, uname);

	myFile << endl;
	myFile << uname << endl;
	myFile << source << endl;
	myFile << dest << endl;
	myFile << label << endl;

	cout << endl << "\tYou have successfully saved this route!" << endl;
	myFile.close();
}

void UserFunc::CheckBalance()
{
	
	filePtr = &uData;

	fstream myFile = filePtr->ReadFile();

	string line, bal, uname;

	cout << endl << "Please confirm your username: ";
	fflush(stdin);
	getline(cin, uname);

	while (!myFile.eof())
	{
		getline(myFile, line);
		if (line == uname)
		{
			getline(myFile, line);
			getline(myFile, bal);
		}
	}
	cout << endl << "Your card balance is: " << bal << endl;
}
