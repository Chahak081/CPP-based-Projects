
#include "MenuHandler.h"

int main()
{
	int choice;
	bool returnMenu;

	// Base class Menu pointer to handle our three menus
	MenuHandler* menu;

	// Derived class objects
	InitialMenu init;
	UserMenu user;
	EmpMenu emp;

	// Opening the metro map
	system("MetroMap.png");

	menu = &init;

	menu->DisplayMenu();
	choice = menu->GetChoice();

	switch (choice)
	{
	case 1:
	case 2:
	{
		do
		{
			menu = &user;
			menu->DisplayMenu();
			menu->GetChoice();
			returnMenu = menu->isReturnMenu();
		} while (returnMenu);
		break;
	}
	case 3:
	{
		do
		{
			menu = &emp;
			menu->DisplayMenu();
			menu->GetChoice();
			returnMenu = menu->isReturnMenu();
		} while (returnMenu);
		break;
	}
	}
	return 0;
}