/*
	Header file to manage Employee Functionalities.
	One class
*/

#pragma once

#include "RouteOptimizer.h"
#include "FileHandler.h"

using namespace std;

class EmpFunc :public StationIdFile, StationPathFile
{
private:
	// Base class pointer to handle derived  classes
	FileHandler* filePtr = nullptr;

	// Derived class objects
	StationIdFile sId;
	StationPathFile sPath;
public:
	// Functions
	void AddStation();
	void AddPath();
};