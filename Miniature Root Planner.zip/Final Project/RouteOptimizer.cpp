#include "RouteOptimizer.h"

void RouteOptimizer::MakeStationMap()
{
	/*
		@return void
		- Opens Station ID file
		- Reads Station Names
		- Stores Station Names and ID in a map
	*/
	
	// Pointer holds address of Station ID File object
	filePtr = &sId;

	// Creating an fstream object for handling Station ID File
	fstream myFile = filePtr->ReadFile();

	// Used to assign integer ID to each station
	int id = 0;

	// Reading each station name from the file
	while (!myFile.eof())
	{
		string stationName;
		getline(myFile, stationName);

		stations[stationName] = id;

		id++;
	}
}

int RouteOptimizer::GetStationId(string str)
{
	/*
		@return int
		- Accessor function
		- Returns Id value for station
	*/
	return(stations[str]);
}

void RouteOptimizer::MakeGraph()
{
	/*
		@return void
		- Opens Station Path file
		- Extracts Station Names and Distances
		- Pushes them into our Adjacency List/Graph
	*/

	// Pointer holds address of Station Path File object
	filePtr = &sPath;

	// Creating an fstream object for handling Station Path File
	fstream myFile = filePtr->ReadFile();

	// Variables to store data extracted from file
	string startStation, endStation, distanceStr;
	float distanceF;

	// Reading all path/edge data from the file
	while (!myFile.eof())
	{
		// Read first Station Name
		getline(myFile, startStation);

		// Get the corresponding station ID
		int startId = GetStationId(startStation);

		// Read second Station Name
		getline(myFile, endStation);

		// Get the corresponding station ID
		int endId = GetStationId(endStation);

		// Read distance (string type)
		getline(myFile, distanceStr);

		// Convert string type to float type
		distanceF = (float)stod(distanceStr);

		// Push all values in adjacency List
		adj[startId].push_back({endId,distanceF});
		adj[endId].push_back({startId,distanceF});
		
		//Skip blank line
		getline(myFile,startStation);
	}
}

FloatArr RouteOptimizer::DijkstraShortestPath(int source,int dest)
{
	/*
		@returns vector<float>
		- Runs Dijkstra's algorithm using adjacency list and prio queue
	*/

	
	//To store the distance travelled from node to node
	FloatArr distance(NODE_COUNT);

	// To store the reverse path
	FloatArr reversePath(NODE_COUNT);

	// Initialize the distance and path arrays
	for (int i = 0; i < NODE_COUNT; i++)
	{
		distance[i] = FLT_MAX;
		reversePath[i] = i;
	}
	distance[source] = 0.f;

	// Initialize the prio queue as pair of (Distance,Source)
	pq.push(make_pair(0.f, source));

	while (!pq.empty())
	{
		float distanceF = pq.top().first; // Cummulative distance, from the source node
		int node = pq.top().second; // Current node
		
		// Pop the element from rear of prio queue
		pq.pop(); 

		//Traverse the adjacency list to find out the distances to adjacent nodes
		for (auto &it : adj[node]) 
		{
			int adjacent_node = it.first;
			float edge_weight = it.second;

			// Checks if the new distance travelled is less than the previous distance travelled
			if (distance[adjacent_node] > (edge_weight + distanceF))
			{
				// Replacing old distance with a better one
				distance[adjacent_node] = distanceF + edge_weight;

				// Pushing (New Distance, Adjacent Node) on the prio queue
				pq.push(make_pair(distance[adjacent_node], adjacent_node));

				// Stores the path from current node to adjacent node
				reversePath[adjacent_node] = node; 
			}
		}
	}
	finalDistance = distance[dest];
	return reversePath;
}

void RouteOptimizer::PutPath(string startStation, string stopStation)
{
	/*
		@return void
		- Takes source and destination as input 
		- Call DijkstraShortestPath function
		- Stores final path in reverse order into a vector
		- Reverse the final path and display to user
	*/

	// Initialize map and adjacency list
	MakeStationMap();
	MakeGraph();

	int source = GetStationId(startStation);
	int dest = GetStationId(stopStation);

	// To store the reverse path by finding shortest path
	FloatArr reversePath = DijkstraShortestPath(source, dest);

	//Reverse the reversed path to get the actual path
	int node = dest;
	while (reversePath[node] != node)
	{
		path.push_back(node);
		node = reversePath[node];
	}
	path.push_back(source);
	reverse(path.begin(), path.end());

	// Display the actual path
	cout << endl << "Path is: " << endl;
	for (auto element : path)
	{
		for (auto& it : stations)
		{
			if (it.second == element)
			{
				cout << "\t" << it.first << endl;
			}
		}
	}
	cout << endl << "Distance covered is: " << finalDistance << " km." << endl;
}

void RouteOptimizer::CalcFare()
{
	/*
		@return void
		- Uses final distance to calculate fare
		- Compares based on distance and day
	*/

	// To store localtime of system
	struct tm localTime;

	// Object of time_t
	time_t now = time(0);

	// Getting localtime
	localtime_s(&localTime, &now);

	if (localTime.tm_wday == 0) // Checking if today is Sunday
	{
		if (finalDistance >= 0.f && finalDistance < 2.f)
			fare = 10;
		else if (finalDistance >= 2.f && finalDistance < 5.f)
			fare = 10;
		else if (finalDistance >= 5.f && finalDistance < 12.f)
			fare = 20;
		else if (finalDistance >= 12.f && finalDistance < 21.f)
			fare = 30;
		else if (finalDistance >= 21.f && finalDistance < 32.f)
			fare = 40;
		else
			fare = 50;
	}
	else 
	{
		if (finalDistance >= 0.f && finalDistance < 2.f)
			fare = 10;
		else if (finalDistance >= 2.f && finalDistance < 5.f)
			fare = 20;
		else if (finalDistance >= 5.f && finalDistance < 12.f)
			fare = 30;
		else if (finalDistance >= 12.f && finalDistance < 21.f)
			fare = 40;
		else if (finalDistance >= 21.f && finalDistance < 32.f)
			fare = 50;
		else
			fare = 60;
	}

	cout << endl << "Total fare for your journey is: Rs. " << fare << endl;
}






