/*
	Header file to manage User Functionalities.
	One class
*/

#pragma once

#include "Login.h"

using namespace std;

class UserFunc:public RouteOptimizer,UserFile,SavedRouteFile
{
	// Base class pointer to handle derived  classes
	FileHandler* filePtr = nullptr;

	// Derived class objects
	SavedRouteFile sRoute;
	UserFile uData;

public:
	// Functions
	void FindRoute();
	void SaveRoute();
	void CheckBalance();
};