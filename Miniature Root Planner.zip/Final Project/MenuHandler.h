/*
	Header file to manage Menus.
	One abstract base class.
	Three derived classes.
*/

#pragma once

#include <iostream>
#include <cstdlib>

#include "Login.h"
#include "UserFunc.h"
#include "EmpFunc.h"


#define WAIT_TIME 3

using namespace std;

class MenuHandler
{
	/*
		Abstract base class for handling initial menu , user and employee menus
		- Calls corresponding login,user and employee menus
	*/
public:
	// Functions

	virtual void DisplayMenu() = 0;
	virtual int GetChoice() = 0;
	virtual bool isReturnMenu() = 0;
};

class InitialMenu : public MenuHandler
{
	/*
		Derived class to manage initial main menu and call required login routines
	*/
public:
	// Functions

	void DisplayMenu();
	int GetChoice();
	bool isReturnMenu();
};

class UserMenu : public MenuHandler
{
	/*
		Derived class to manage user main menu and call required functionalities
	*/
public:
	// Functions

	void DisplayMenu();
	int GetChoice();
	bool isReturnMenu();

};

class EmpMenu : public MenuHandler
{
	/*
		Derived class to manage employee main menu and call required functionalities
	*/
public:
	// Functions

	void DisplayMenu();
	int GetChoice();
	bool isReturnMenu();
};

