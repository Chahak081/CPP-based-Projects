/*
	Header file to manage our pathfinding algorithm and functionality logic
	One class.
*/

#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <cfloat>
#include <ctime>
#include <vector>
#include <queue>
#include <utility>
#include <algorithm>
#include <map> 

#include "FileHandler.h"

// Number of stations on a graph
#define NODE_COUNT 93

using namespace std;


// User-defined datatypes

typedef map<string,int> Map;
typedef priority_queue< pair<float, int>, vector<pair<float, int>>, greater<pair<float, int>>> PrioQueue;
typedef vector<pair<int, float>> AdjacencyList;
typedef vector<int> IntegerArr;
typedef vector<float> FloatArr;


class RouteOptimizer: public StationIdFile,StationPathFile
{
private:
	// Variables
	// Base class pointer to handle derived classes
	FileHandler * filePtr = nullptr;

	// Derived class objects
	StationIdFile sId;
	StationPathFile sPath;

	Map stations; // A map STL to handle key:value of Station Name and ID
	PrioQueue pq; // A priority queue STL for implementing pathfinding algorithm
	AdjacencyList adj[NODE_COUNT]; // A vector used to handle graph
	IntegerArr path;

	
	float finalDistance = 0.f; // Final distance travelled
	int fare = 0; // Final cost

	// Helper Function - restricted access
	FloatArr DijkstraShortestPath(int, int);

public:
	// Functions
	void MakeStationMap();
	void MakeGraph();
	int GetStationId(string);
	void PutPath(string,string);
	void CalcFare();
};

