/*
	Header file to manage external file and program interfacing
	One abstract base class.
	Five derived classes.
*/

#pragma once

#include <iostream>
#include <fstream>

using namespace std;

class FileHandler
{
	/*
		Abstract base class for handling all types files present in our database
		- Opens files to extract data
		- Opens file to insert data
	*/
public:
	virtual fstream ReadFile() = 0;
	virtual fstream WriteFile() = 0;
};

class UserFile : public FileHandler
{
	/*
		Derived class to manage login and balance data of general end-users
	*/
public:
	fstream ReadFile();
	fstream WriteFile();
};

class EmpFile : public FileHandler
{
	/*
		Derived class to manage login data of metro employee
	*/
public:
	fstream ReadFile();
	fstream WriteFile();
};

class StationIdFile : public FileHandler
{
	/*
		Derived class to manage the ID of each metro station
	*/
public:
	fstream ReadFile();
	fstream WriteFile();
};

class StationPathFile : public FileHandler
{
	/*
		Derived class to manage the paths between two stations
	*/
public:
	fstream ReadFile();
	fstream WriteFile();
};

class SavedRouteFile : public FileHandler
{
	/*
		Derived class to manage user's saved metro routes
	*/
public:
	fstream ReadFile();
	fstream WriteFile();
};



