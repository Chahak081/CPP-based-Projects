#include "EmpFunc.h"

void EmpFunc::AddStation()
{
	// Pointer holds address of Station ID File object
	filePtr = &sId;

	// Creating an fstream object for handling Station ID File
	fstream myFile = filePtr->WriteFile();
	
	string stationName;

	// Get station Name from admin

	cout << endl << "Enter the station name here: ";
	getline(cin, stationName);

	// Store station Name in file

	myFile << endl;
	myFile << stationName << endl;

	cout << endl << "\tYou have successfully saved the station!" << endl;

	myFile.close();
}

void EmpFunc::AddPath()
{
	// Pointer holds address of Station Path File object
	filePtr = &sPath;

	// Creating an fstream object for handling Station ID File
	fstream myFile = filePtr->WriteFile();

	string firstStationName, secondStationName;
	float distanceF;

	// Get station Names and distance from admin

	cout << endl << "Enter the first station name here: ";
	getline(cin, firstStationName);

	cout << endl << "Enter the second station name here: ";
	getline(cin, secondStationName);

	cout << endl << "Enter the distance between two of them (in km): ";
	cin >> distanceF;

	myFile << endl;
	myFile << firstStationName << endl;
	myFile << secondStationName << endl;
	myFile << distanceF << endl;

	cout << endl << "\tYou have successfully saved the path!" << endl;

	myFile.close();
}
