#include "MenuHandler.h"

void InitialMenu::DisplayMenu()
{
    /*
        return @void
        - A simple function to display menu to console
    */
    
    cout << "\t\t" << R"( 
 __   __                    .                            .___                .          
 |    |  ` , __   `   ___  _/_   ,   . .___    ___       /   \   __.  ,   . _/_     ___ 
 |\  /|  | |'  `. |  /   `  |    |   | /   \ .'   `      |__-' .'   \ |   |  |    .'   `
 | \/ |  | |    | | |    |  |    |   | |   ' |----'      |  \  |    | |   |  |    |----'
 /    /  / /    | / `.__/|  \__/ `._/| /     `.___,      /   \  `._.' `._/|  \__/ `.___,
                                                                                        
 .___   .                                    
 /   \  |     ___  , __   , __     ___  .___ 
 |,_-'  |    /   ` |'  `. |'  `. .'   ` /   \
 |      |   |    | |    | |    | |----' |   '
 /     /\__ `.__/| /    | /    | `.___, /    
                                             

)" << endl;
    cout << "\t" << "Welcome to the Delhi Metro Miniature Route Planner! Are you a:" << endl
        << "\t\t" << "1. Existing User?" << endl
        << "\t\t" << "2. New User?" << endl
        << "\t\t" << "3. Employee?" << endl;
}

int InitialMenu::GetChoice()
{
    /*
        @return int
        - Extract user choice from console
        - Call routines based on user choice
    */
    
    int inputChoice;
    bool isValidChoice = false;
    Login * logPtr = nullptr;
    UserLogin us;
    EmpLogin emp;

    while (!isValidChoice)
    {
        cout << endl << "Enter your choice here: ";
        fflush(stdin);
        cin >> inputChoice;
        switch (inputChoice)
        {
        case 1:
        {
            isValidChoice = true;
            logPtr = &us;
            logPtr->GetDetails();
            return inputChoice;
        }
        case 2:
        {
            isValidChoice = true;
            us.UserReg();
            return inputChoice;
        }
        case 3:
        {
            isValidChoice = true;
            logPtr = &emp;
            logPtr->GetDetails();
            return inputChoice;
        }
        default:
        {
            cout << endl << "Error! Please enter a choice from 1-3" << endl;
        }
        }
    }

}

bool InitialMenu::isReturnMenu()
{
    return false;
}

void UserMenu::DisplayMenu()
{
    /*
        return @void
        - A simple function to display menu to console
    */

    system("cls");
    cout << "\t\t" << R"( 
 _______         _           _______                      
(_______)       (_)         (_______)                     
 _  _  _  _____  _  ____     _  _  _  _____  ____   _   _ 
| ||_|| |(____ || ||  _ \   | ||_|| || ___ ||  _ \ | | | |
| |   | |/ ___ || || | | |  | |   | || ____|| | | || |_| |
|_|   |_|\_____||_||_| |_|  |_|   |_||_____)|_| |_||____/ 
                                                          

)" << endl;
    cout << "\t" << "Welcome! What would you like to do?" << endl
        << "\t\t" << "1. Find Route" << endl
        << "\t\t" << "2. Save Route" << endl
        << "\t\t" << "3. Check Balance" << endl
        << "\t\t" << "4. Exit" << endl;

}

int UserMenu::GetChoice()
{
    /*
        @return int
        - Extract user choice from console
        - Call routines based on user choice
    */

    int inputChoice;
    bool isValidChoice = false;
    UserFunc user;

    while (!isValidChoice)
    {
        cout << endl << "Enter your choice here: ";
        fflush(stdin);
        cin >> inputChoice;
        switch (inputChoice)
        {
        case 1:
        {
            cout << endl << "\tMoving to Route Finder!";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            system("cls");
            cout << "\t\t" << R"( 
 ______                                   _______  _             _               
(_____ \                  _              (_______)(_)           | |              
 _____) )  ___   _   _  _| |_  _____      _____    _  ____    __| | _____   ____ 
|  __  /  / _ \ | | | |(_   _)| ___ |    |  ___)  | ||  _ \  / _  || ___ | / ___)
| |  \ \ | |_| || |_| |  | |_ | ____|    | |      | || | | |( (_| || ____|| |    
|_|   |_| \___/ |____/    \__)|_____)    |_|      |_||_| |_| \____||_____)|_|    
                                                                                 

)" << endl;
            isValidChoice = true;
            fflush(stdin);
            user.FindRoute();
            return inputChoice;
        }
        case 2:
        {
            cout << endl << "\tMoving to Route Saver!";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            system("cls");
            cout << "\t\t" << R"( 
 ______                                    ______                             
(_____ \                  _               / _____)                            
 _____) )  ___   _   _  _| |_  _____     ( (____   _____  _   _  _____   ____ 
|  __  /  / _ \ | | | |(_   _)| ___ |     \____ \ (____ || | | || ___ | / ___)
| |  \ \ | |_| || |_| |  | |_ | ____|     _____) )/ ___ | \ V / | ____|| |    
|_|   |_| \___/ |____/    \__)|_____)    (______/ \_____|  \_/  |_____)|_|    
                                                                              

)" << endl;
            isValidChoice = true;
            fflush(stdin);
            user.SaveRoute();
            return inputChoice;
        }
        case 3:
        {
            cout << endl << "\tMoving to Balance Checker!";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            system("cls");
            cout << "\t\t" << R"( 
 ______          _                                   _______  _                    _                   
(____  \        | |                                 (_______)| |                  | |                  
 ____)  ) _____ | |  _____  ____    ____  _____      _       | |__   _____   ____ | |  _  _____   ____ 
|  __  ( (____ || | (____ ||  _ \  / ___)| ___ |    | |      |  _ \ | ___ | / ___)| |_/ )| ___ | / ___)
| |__)  )/ ___ || | / ___ || | | |( (___ | ____|    | |_____ | | | || ____|( (___ |  _ ( | ____|| |    
|______/ \_____| \_)\_____||_| |_| \____)|_____)     \______)|_| |_||_____) \____)|_| \_)|_____)|_|    
                                                                                                       
)" << endl;
            isValidChoice = true;
            fflush(stdin);
            user.CheckBalance();
            return inputChoice;
        }
        case 4:
        {
            cout << endl << "\tThank you for using Miniature Route Planner! Exiting";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            exit(132);
        }
        default:
        {
            cout << endl << "Error! Please enter a choice from 1-3" << endl;
            break;
        }
        }
    }

}

bool UserMenu::isReturnMenu()
{
    char returnChar;
    cout << endl << "Would you like to return to the main menu? (y/n): ";
    cin >> returnChar;
    if (returnChar == 'y' || returnChar == 'Y')
    {
        cout << endl << "\tMoving to User Main Menu!";
        for (int i = 0; i < WAIT_TIME; i++)
        {
            cout << ".";
            Sleep(1000);
        }
        cout << "\t" << endl;
        return true;
    }
    else
    {
        return false;
    }
}

void EmpMenu::DisplayMenu()
{
    /*
        return @void
        - A simple function to display menu to console
    */
    
    system("cls");
    cout << "\t\t" << R"( 
 _______         _           _______                      
(_______)       (_)         (_______)                     
 _  _  _  _____  _  ____     _  _  _  _____  ____   _   _ 
| ||_|| |(____ || ||  _ \   | ||_|| || ___ ||  _ \ | | | |
| |   | |/ ___ || || | | |  | |   | || ____|| | | || |_| |
|_|   |_|\_____||_||_| |_|  |_|   |_||_____)|_| |_||____/ 
                                                          

)" << endl;
    cout << endl << "\t" << "Welcome! What would you like to do?" << endl
        << "\t\t" << "1. Add Station" << endl
        << "\t\t" << "2. Add Path" << endl
        << "\t\t" << "3. Exit" << endl;
}

int EmpMenu::GetChoice()
{
    /*
        @return int
        - Extract user choice from console
        - Call routines based on user choice
    */
    
    int inputChoice;
    bool isValidChoice = false;
    EmpFunc emp;

    while (!isValidChoice)
    {
        cout << endl << "Enter your choice here: ";
        fflush(stdin);
        cin >> inputChoice;
        switch (inputChoice)
        {
        case 1:
        {
            cout << endl << "\tMoving to Station Adder!";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            system("cls");
            cout << "\t\t" << R"( 
  ______                       _                    _______      _      _               
 / _____)   _             _   (_)                  (_______)    | |    | |              
( (____   _| |_  _____  _| |_  _   ___   ____       _______   __| |  __| | _____   ____ 
 \____ \ (_   _)(____ |(_   _)| | / _ \ |  _ \     |  ___  | / _  | / _  || ___ | / ___)
 _____) )  | |_ / ___ |  | |_ | || |_| || | | |    | |   | |( (_| |( (_| || ____|| |    
(______/    \__)\_____|   \__)|_| \___/ |_| |_|    |_|   |_| \____| \____||_____)|_|    
                                                                                        

)" << endl;
            isValidChoice = true;
            emp.AddStation();
            return inputChoice;
        }
        case 2:
        {
            cout << endl << "\tMoving to Path Adder!";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            system("cls");
            cout << "\t\t" << R"( 
 ______                 _          _______      _      _               
(_____ \           _   | |        (_______)    | |    | |              
 _____) ) _____  _| |_ | |__       _______   __| |  __| | _____   ____ 
|  ____/ (____ |(_   _)|  _ \     |  ___  | / _  | / _  || ___ | / ___)
| |      / ___ |  | |_ | | | |    | |   | |( (_| |( (_| || ____|| |    
|_|      \_____|   \__)|_| |_|    |_|   |_| \____| \____||_____)|_|    
                                                                       

)" << endl;
            isValidChoice = true;
            emp.AddPath();
            return inputChoice;
        }
        case 3:
        {
            cout << endl << "\tThank you for using Miniature Route Planner! Exiting";
            for (int i = 0; i < WAIT_TIME; i++)
            {
                cout << ".";
                Sleep(1000);
            }
            cout << "\t" << endl;
            exit(132);
        }
        default:
        {
            cout << endl << "Error! Please enter a choice from 1-2" << endl;
            break;
        }
        }
    }

}

bool EmpMenu::isReturnMenu()
{
    char returnChar;
    cout << endl << "Would you like to return to the main menu? (y/n): ";
    cin >> returnChar;
    if (returnChar == 'y' || returnChar == 'Y')
    {
        cout << endl << "\tMoving to Employee Main Menu!";
        for (int i = 0; i < WAIT_TIME; i++)
        {
            cout << ".";
            Sleep(1000);
        }
        cout << "\t" << endl;
        return true;
    }
    else
    {
        return false;
    }
}
