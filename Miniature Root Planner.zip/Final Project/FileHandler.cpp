#include "FileHandler.h"

using namespace std;

fstream UserFile::ReadFile()
{
	/*
		@return fstream object
		- Opens the User Data File in input mode
		- Data to program from the file
	*/
	fstream myFile("UserData.txt", ios::in);
	return(myFile);
}

fstream UserFile::WriteFile()
{
	/*
		@return fstream object
		- Opens the User Data File in output mode
		- Data from program to the file
	*/
	fstream myFile("UserData.txt", ios::out | ios::app);
	return(myFile);
}

fstream EmpFile::ReadFile()
{
	/*
		@return fstream object
		- Opens the Emp Data File in input mode
	*/
	fstream myFile("EmpData.txt", ios::in);
	return(myFile);
}

fstream EmpFile::WriteFile()
{
	/*
		@return fstream object
		- Opens the Emp Data File in output mode
	*/
	fstream myFile("EmpData.txt", ios::out | ios::app);
	return(myFile);
}

fstream StationIdFile::ReadFile()
{
	/*
		@return fstream object
		- Opens the Station Id File in input mode
	*/
	fstream myFile("StationId.txt", ios::in);
	return(myFile);
}

fstream StationIdFile::WriteFile()
{
	/*
		@return fstream object
		- Opens the Station Id File in output mode
	*/
	fstream myFile("StationId.txt", ios::out | ios::app);
	return(myFile);
}

fstream StationPathFile::ReadFile()
{
	/*
		@return fstream object
		- Opens the Station Path File in input mode
	*/
	fstream myFile("StationPath.txt", ios::in);
	return(myFile);
}

fstream StationPathFile::WriteFile()
{
	/*
		@return fstream object
		- Opens the Station Path File in output mode
	*/
	fstream myFile("StationPath.txt", ios::out | ios::app);
	return(myFile);
}

fstream SavedRouteFile::ReadFile()
{
	/*
		@return fstream object
		- Opens the Saved Route File in input mode
	*/
	fstream myFile("SavedRoute.txt", ios::in);
	return(myFile);
}

fstream SavedRouteFile::WriteFile()
{
	/*
		@return fstream object
		- Opens the Saved Route File in output mode
	*/
	fstream myFile("SavedRoute.txt", ios::out | ios::app);
	return(myFile);
}


