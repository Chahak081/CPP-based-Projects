#include "Login.h"

void UserLogin::GetDetails()
{
	/*
		@return void
		- Extract user details from console
		- Check for vailidity of details
	*/
	string inputUname;
	string inputPass;
	bool isValid = true;
	// Get user input for username until valid username entered
	do
	{
		cout << endl << "Enter your username (case-sensitive) : ";
		cin >> inputUname;
		isValid = IsIDValid(inputUname);
		if (!isValid) // Checking for invalidity
		{
			cout << endl << "Invalid Username! Please enter a valid username..." << endl;
			isValid = false;
		}
		else
		{
			Uname = inputUname;
		}
	} while (!isValid);

	// Get user input for password until valid password entered
	do
	{
		int i = 0;
		cout << endl << "Enter your password (case-sensitive) : ";
		cin >> inputPass;
		isValid = IsPassValid(inputPass);
		if (!isValid) // Checking for invalidity
		{
			cout << endl << "Invalid Password ! Please enter a valid password..." << endl;
			isValid = false;
		}
		else
		{
			Pass = inputPass;
		}
	} while (!isValid);

	cout << endl << "\tYou have successfully logged in!";
	for (int i = 0; i < WAIT_TIME; i++)
	{
		cout << ".";
		Sleep(1000);
	}
	cout << "\t" << endl;
}

bool UserLogin::IsIDValid(string inputUname)
{
	/*
		@return bool
		- Opens UserData file
		- Checks for validity of ID
	*/

	// To store data read from file
	string line;

	// Pointer holds address of User Data text file
	filePtr = &uData;

	// Creating an fstream object for handling Station Path File
	fstream myFile = filePtr->ReadFile();

	while (!myFile.eof())
	{
		getline(myFile, line);
		if (line == inputUname)
		{
			return true;
		}
	}
	return false;
	myFile.close();
}

bool UserLogin::IsPassValid(string inputPass)
{
	/*
		@return bool
		- Opens UserData file
		- Checks for validity of Password
	*/
	
	string line;
	filePtr = &uData;
	fstream myFile = filePtr->ReadFile();
	while (!myFile.eof())
	{
		getline(myFile, line);
		if (line == inputPass)
		{
			return true;
		}
	}
	return false;
	myFile.close();
}

// Accessors
string UserLogin::PutID()
{ return(Uname); }

string UserLogin::PutPass()
{ return(Pass);}

void UserLogin::UserReg()
{
	/*
		@return void
		- Registering a new user
	*/
	string tempUname;
	string tempPass;
	filePtr = &uData;
	fstream myFile = filePtr->WriteFile();
	cout << endl << "\tLet's get started by creating a username and password!" << endl;
	cout << endl << "Enter any username here: ";
	cin >> tempUname;
	cout << endl << "Enter a password here: ";
	cin >> tempPass;

	myFile << endl;
	myFile << tempUname << endl;
	myFile << tempPass << endl;
	myFile << "Rs. 0" << endl;

	Uname = tempUname;
	Pass = tempPass;

	cout << endl << "\tYou have been registered!";
	for (int i = 0; i < WAIT_TIME; i++)
	{
		cout << ".";
		Sleep(1000);
	}
	cout << "\t" << endl;
	myFile.close();
}

void EmpLogin::GetDetails()
{
	/*
		@return void
		- Extract employee details from console
		- Check for vailidity of details
	*/
	
	string inputUname;
	string inputPass;
	bool isValid = true;
	// Get user input for username until valid username entered
	do
	{
		cout << endl << "Enter your username (case-sensitive) : ";
		cin >> inputUname;
		isValid = IsIDValid(inputUname);
		if (!isValid) // Checking for invalidity
		{
			cout << endl << "Invalid Username! Please enter a valid username..." << endl;
			isValid = false;
		}
	} while (!isValid);

	// Get user input for password until valid password entered
	do
	{
		int i = 0;
		cout << endl << "Enter your password (case-sensitive) : ";
		cin >> inputPass;
		isValid = IsPassValid(inputPass);
		if (!isValid) // Checking for invalidity
		{
			cout << endl << "Invalid Password ! Please enter a valid password..." << endl;
			isValid = false;
		}
	} while (!isValid);

	cout << endl << "\tYou have successfully logged in!";
	for (int i = 0; i < WAIT_TIME; i++)
	{
		cout << ".";
		Sleep(1000);
	}
	cout << "\t" << endl;
}
bool EmpLogin::IsIDValid(string inputUname)
{
	/*
		@return bool
		- Opens EmpData file
		- Checks for validity of ID
	*/
	
	string line;
	filePtr = &eData;
	fstream myFile = filePtr->ReadFile();

	while (!myFile.eof())
	{
		getline(myFile, line);
		if (line == inputUname)
		{
			return true;
		}
	}
	return false;

	myFile.close();
}

bool EmpLogin::IsPassValid(string inputPass)
{
	/*
		@return bool
		- Opens EmpData file
		- Checks for validity of Password
	*/

	string line;
	filePtr = &eData;
	fstream myFile = filePtr->ReadFile();
	while (!myFile.eof())
	{
		getline(myFile, line);
		if (line == inputPass)
		{
			return true;
		}
	}
	return false;
	myFile.close();
}

// Accessors
string EmpLogin::PutID()
{ return(Uname); }

string EmpLogin::PutPass()
{ return(Pass); }
