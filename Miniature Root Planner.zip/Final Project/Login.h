/*
	Header file to manage User and Employee login
	One abstract base class.
	Two derived classes.
*/

#pragma once

#include "RouteOptimizer.h"
#include "FileHandler.h"
#include <windows.h> 

#define WAIT_TIME 3

using namespace std;

class Login
{
	/*
		Abstract base class for various logins
	*/
public:
	// Base class file pointer to handle derived classes
	FileHandler* filePtr = nullptr;
	
	// Functions
	virtual void GetDetails() = 0;
	virtual bool IsIDValid(string) = 0;
	virtual bool IsPassValid(string) = 0;
	virtual string PutID() = 0;
	virtual string PutPass() = 0;
};

class UserLogin : public Login,UserFile
{
	/*
		Derived class to manage user login
	*/
private:
	// Derived class object
	UserFile uData;

	// Variables to store valid details
	string Uname;
	string Pass;

public:
	// Functions
	void GetDetails();
	bool IsIDValid(string);
	bool IsPassValid(string);

	// Non-virtual function unique to derived class
	void UserReg();

	// Accessors
	string PutID();
	string PutPass();
	
};

class EmpLogin : public Login,EmpFile
{
	/*
		Derived class to manage user login
	*/
private:
	// Derived class object
	EmpFile eData;

	// Variables to store valid details
	string Uname;
	string Pass;

public:
	// Functions
	void GetDetails();
	bool IsIDValid(string);
	bool IsPassValid(string);

	// Accessors
	string PutID();
	string PutPass();
};